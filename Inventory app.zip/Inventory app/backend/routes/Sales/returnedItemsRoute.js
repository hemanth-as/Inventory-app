const express = require('express');
const returnedItemsModel = require('../../models/Sales/returnedItems');
const salesReturnModel = require('../../models/Sales/salesReturnModel');
const itemsModel = require('../../models/Inventory/itemsModel');
const salesOrderModel = require('../../models/Sales/salesOrderModel');
const router = express.Router();

router.put('/addinventory', async (req, res) => {
    const body = req.body;

    const salesOrders = await salesOrderModel.find({ order_id: body.order_id });
    for (const orders of salesOrders) {
        const items = await itemsModel.find({ _id: orders.item_id });
        if (items.length > 0) {
            const item = items[0];
            item.opening_stock += body.returned_quantity;
            await item.save();
        }
    }
    const salesReturn = await salesReturnModel.findOneAndUpdate({ order_id: body.order_id }, { $set: { status: body.status } });
    const returnItems = new returnedItemsModel(req.body);
    const data = await returnItems.save();
    res.send({ success: salesOrders, salesReturn, data });
});

module.exports = router;